// Generated using https://github.com/a2x/cs2-dumper
// 2026-08-20 01:42:06.025268700 UTC

#![allow(non_upper_case_globals, non_camel_case_types, non_snake_case, unused)]

pub mod cs2_dumper {
    pub mod schemas {
        // Module: host.dll
        // Class count: 2
        // Enum count: 0
        pub mod host_dll {
            // Parent: None
            // Field count: 1
            pub mod EmptyTestScript {
                pub const m_hTest: usize = 0x10; // CAnimScriptParam<float32>
            }
            // Parent: None
            // Field count: 1
            pub mod CAnimScriptBase {
                pub const m_bIsValid: usize = 0x8; // bool
            }
        }
    }
}
