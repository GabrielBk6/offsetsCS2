// Generated using https://github.com/a2x/cs2-dumper
// 2026-08-20 01:42:06.025268700 UTC

#![allow(non_upper_case_globals, unused)]

pub mod cs2_dumper {
    pub mod offsets {
        // Module: client.dll
        pub mod client_dll {
            pub const dwCSGOInput: usize = 0x23BFB20;
            pub const dwEntityList: usize = 0x2555050;
            pub const dwGameEntitySystem: usize = 0x2555050;
            pub const dwGameEntitySystem_highestEntityIndex: usize = 0x2090;
            pub const dwGameRules: usize = 0x23A9BD8;
            pub const dwGlobalVars: usize = 0x2095D48;
            pub const dwGlowManager: usize = 0x23A6908;
            pub const dwLocalPlayerController: usize = 0x2384DB0;
            pub const dwLocalPlayerPawn: usize = 0x23AA118;
            pub const dwPlantedC4: usize = 0x2374898;
            pub const dwPrediction: usize = 0x23AA020;
            pub const dwSensitivity: usize = 0x23A7428;
            pub const dwSensitivity_sensitivity: usize = 0x58;
            pub const dwViewAngles: usize = 0x23C01A8;
            pub const dwViewMatrix: usize = 0x23AF550;
            pub const dwViewRender: usize = 0x23AF5A8;
            pub const dwWeaponC4: usize = 0x2322DA0;
        }
        // Module: engine2.dll
        pub mod engine2_dll {
            pub const dwBuildNumber: usize = 0x60F594;
            pub const dwNetworkGameClient: usize = 0x90D4B0;
            pub const dwNetworkGameClient_clientTickCount: usize = 0x378;
            pub const dwNetworkGameClient_deltaTick: usize = 0x24C;
            pub const dwNetworkGameClient_isBackgroundMap: usize = 0x2C141F;
            pub const dwNetworkGameClient_localPlayer: usize = 0xF8;
            pub const dwNetworkGameClient_maxClients: usize = 0x240;
            pub const dwNetworkGameClient_serverTickCount: usize = 0x24C;
            pub const dwNetworkGameClient_signOnState: usize = 0x230;
            pub const dwWindowHeight: usize = 0x9118DC;
            pub const dwWindowWidth: usize = 0x9118D8;
        }
        // Module: inputsystem.dll
        pub mod inputsystem_dll {
            pub const dwInputSystem: usize = 0x45BA0;
        }
        // Module: matchmaking.dll
        pub mod matchmaking_dll {
            pub const dwGameTypes: usize = 0x1ADF80;
        }
        // Module: soundsystem.dll
        pub mod soundsystem_dll {
            pub const dwSoundSystem: usize = 0x54B5D0;
            pub const dwSoundSystem_engineViewData: usize = 0x7C;
        }
    }
}
